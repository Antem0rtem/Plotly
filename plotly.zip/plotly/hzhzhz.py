import numpy as np
import matplotlib.pyplot as plt

N = 14
a = 0.5

x_values = np.linspace(-100, 100, 100)
y_values = N * (x_values / N + 1/2) ** a - N / 2 

plt.plot(x_values, y_values)
plt.title("№23")
plt.xlabel('x')
plt.ylabel('y')
plt.grid(True)
plt.show()